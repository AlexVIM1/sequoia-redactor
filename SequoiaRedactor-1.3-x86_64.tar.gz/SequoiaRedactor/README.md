# Sequoia
Sequoia Redactor v1.3

Made with Qt 5.14.1

Supporting on GNU/Linux

Binary files


# Program
Binary files are located in "bin/"

Main executable file is "bin/SequoiaRedactor"


# Redactor
Upper field must contain path to file

Lower field intended for text


* File>Find appends chosen path to file to upper field

* File>Save saves entered text from lower field to chosen file in upper field

* File>Open opens text file from upper field to lower field

* File>Create creates file with upper field's name

* File>Clear deleting all text from lower field


* Text>Font>8 sets DejaVu Sans Mono 8 font in lower field

* Text>Font>9 sets DejaVu Sans Mono 9 font in lower field

* Text>Font>9 sets DejaVu Sans Mono 9 font in lower field

* Text>Font>9 sets DejaVu Sans Mono 9 font in lower field

* Text>Font>10 sets DejaVu Sans Mono 10 font in lower field

* Text>Font>11 sets DejaVu Sans Mono 11 font in lower field

* Text>Font>12 sets DejaVu Sans Mono 12 font in lower field

Standart chosen DejaVu Sans Mono 12 font


* Window>Theme>Default sets Default theme

* Window>Theme>Dark sets Dark theme

* Window>Theme>Light sets Light theme

Standart chosen Default theme


* Help>Version displays version of product

* Help>Qt displays version of Qt via created product
