# Sequoia
Sequoia Redactor v1.5-2  
Made with Qt 5.15.0  
Supporting on GNU/Linux  
Source files
  
# Program
All source code are located in "build/" folder  

# Redactor
* In "File" you can do any actions with files in your computer  
* In "Text" you can set any parameters to editing text (font, size etc)  
* In "Window" you can set any parameters to redactor view (theme, configure toolBar etc)  
* In "Help" you can see information about redactor  
